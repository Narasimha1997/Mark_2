#!/usr/bin/env python
import os
import sys
from uploads import settings

if __name__ == "__main__":
    settings.get_hosts()
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "uploads.settings")

    from django.core.management import execute_from_command_line

    execute_from_command_line(sys.argv)
