from uploads import settings
from subprocess import call
import socket

def read_hosts():
    file_=open("allowed_hosts.txt","r")
    for hosts in file_.readlines():
        settings.ALLOWED_HOSTS.append(hosts)

if __name__=="__main__":
    read_hosts()
    print(str(settings.ALLOWED_HOSTS))
    MY_IPSTR=socket.gethostbyname(socket.gethostname())+":8000"
    call(["python","server-http//manage.py","runserver",MY_IPSTR])
    